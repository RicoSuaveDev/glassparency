# Glassparency

![A glass lens bending the headline “Glass that bends the page.”](https://cdn.jsdelivr.net/npm/glassparency@1.0.4-preview/media/hero-light.webp)

**[See it live →](https://ricosuavedev.github.io/glassparency/)** Drag the lens, flip the settings, melt the drops.

Apple‑style **Liquid Glass** for the web. The glass really bends what is behind it:
- clear, saturated glass with a wide squircle rim that refracts the page, plus colour fringing;
- a specular rim lit from the top‑left, and a soft inner glow;
- controls that grow and light up from the touch point when pressed;
- **liquid morphing**: shapes melt together and split apart;
- light and dark themes;
- an automatic CSS fallback wherever WebGL can't run.

It only changes the **look**. Layout, text, icons, focus, clicks and accessibility stay plain HTML.
The glass is drawn behind your elements. When it can't run, your own CSS shows instead.

Under the hood:
- WebGL ([three.js](https://threejs.org) through [react-three-fiber](https://r3f.docs.pmnd.rs) and drei's `MeshTransmissionMaterial`).
- In Chromium browsers, floating glass refracts the **live page in real time** with SVG backdrop filters.

## What it looks like

![Glass controls over flat colour artwork: a media player, settings rows, liquid drops and a thick glass bar over large type](https://cdn.jsdelivr.net/npm/glassparency@1.0.4-preview/media/grid-light.webp)

| ![A glass media player floating over poster artwork](https://cdn.jsdelivr.net/npm/glassparency@1.0.4-preview/media/player.webp) | ![Two glass drops melting into one over black and white stripes](https://cdn.jsdelivr.net/npm/glassparency@1.0.4-preview/media/morph.webp) |
|---|---|
| Floating controls bend the artwork behind them | Liquid morph: shapes melt together and split apart |

![The same page in dark mode](https://cdn.jsdelivr.net/npm/glassparency@1.0.4-preview/media/grid-dark.webp)

---

## Two ways to use it

### 1. React apps (React 19)

```bash
npm install glassparency react react-dom three @react-three/fiber @react-three/drei
```

```jsx
import { useRef } from 'react';
import { GlassProvider, Glass, useGlass } from 'glassparency';

// Wrap your app once.
root.render(
  <GlassProvider>
    <App />
  </GlassProvider>
);

// Any element, one line:
function SaveButton() {
  const ref = useRef(null);
  useGlass(ref, 'button');                         // the look = the "button" preset group
  return <button ref={ref}>Save</button>;
}

// Or the wrapper component:
<Glass as="section" group="card">…</Glass>

// Per-element changes on top of the group:
useGlass(ref, 'card', { tint: '#e0e7ff', tintOpacity: 0.7 });

// Switch groups with state (e.g. a toggle), or null = no glass:
useGlass(ref, on ? 'switchOn' : 'switch');
```

- **Server rendering** works (Next.js, Remix, Astro islands…). The package is marked `'use client'`. On the
  server and during hydration it renders only your children, then it starts in the browser.
- **TypeScript** types are included.

### 2. Any website, no React (one `<script>`)

```html
<script src="https://unpkg.com/glassparency/dist/glassparency.standalone.js"></script>

<button data-glassparency="button">Save</button>
<div data-glassparency="card" data-glassparency-props='{"tint":"#e0e7ff"}'>…</div>
```

- **Attributes:** every element with `data-glassparency="<group>"` gets glass. That includes elements added later,
  and the glass follows changes to the attributes.
- **Size:** the script holds React, three.js and everything else (≈ 420 kB gzipped). It works on WordPress,
  Shopify, Webflow or plain HTML.
- **Settings:** set `window.GlassparencyConfig = { … }` *before* the script, or call `Glassparency.configure({ … })`.
- **Starting it yourself:** add `data-manual` to the `<script>` tag, then call `Glassparency.start()`.

```js
Glassparency.start({ config, auto: true, injectStyles: true, nonce });
const glass = Glassparency.attach(element, 'buttonPrimary', { pressScale: 1.05 });
glass.setProps({ tintOpacity: 0.9 });
glass.destroy();
Glassparency.stop();          // remove all glass
Glassparency.status();        // { state: 'loading' | 'on' | 'fallback', reason }
```

From a bundler without React, use the same API through `attachGlass()` and `configureGlass()`.
You still need `<GlassProvider>` (or the script build) running somewhere on the page.

---

## Switches and sliders

Liquid Glass controls that behave like the ones in macOS 26:
- **Switch:** click it, or drag the knob. While pressed, the solid knob swells into clear glass that bends the
  track behind it. The track colour fades between off and on as the knob moves, and it snaps to the nearer side
  when you let go.
- **Slider:** drag the knob or click the track. The knob turns into glass while you hold it, with the fill
  showing through.
- **Keyboard and screen readers:** Space/Enter toggles a switch; arrows, Page Up/Down and Home/End move a
  slider. They use `role="switch"` and `role="slider"` with live `aria-*` values.
- **Fallback:** without WebGL they keep the same shapes and motion in plain CSS.

```jsx
import { GlassSwitch, GlassSlider } from 'glassparency';

<GlassSwitch checked={wifi} onChange={setWifi} aria-label="Wi-Fi" />
<GlassSlider value={volume} onChange={setVolume} min={0} max={100} aria-label="Volume" />
```

- Both work controlled (`checked` / `value`) or uncontrolled (`defaultChecked` / `defaultValue`).
- `GlassSlider` also has `step` and `onChangeEnd` (called when the user lets go).
- Size them with CSS (`width` / `height`). The default switch is 46×26 px; a slider is 28 px tall and fills its
  container's width.
- Their looks are the config groups `switch` / `switchOn` (track), `switchKnob` / `switchKnobActive`,
  `sliderTrack`, `sliderFill` and `sliderKnob` / `sliderKnobActive`. Pass `groups` to use your own.

**Without React,** use `createSwitch(el, { checked, onChange })` and `createSlider(el, { value, min, max, onChange })`.
With the script build, just mark native inputs:

```html
<label for="wifi">Wi-Fi</label>
<input id="wifi" name="wifi" type="checkbox" checked data-glassparency-switch>
<input name="volume" type="range" min="0" max="10" value="4" aria-label="Volume" data-glassparency-slider>
```

The input stays in the page, hidden and kept in sync, so forms, `<label for>` and `input` / `change` listeners
keep working.

---

## Built-in groups (presets)

A **group** is a named look. These come built in. List them with `glassGroupNames()`, or read
`glassparency/glass.config.json`.

| Group | Use |
|---|---|
| `card`, `panel`, `tile`, `column` | Content surfaces |
| `button`, `buttonPrimary`, `buttonDanger`, `buttonGhost`, `buttonTint`, `buttonTintOn`, `buttonCall` | Capsule buttons |
| `iconButton`, `iconButtonActive`, `iconButtonCall` | Round icon buttons |
| `switch`, `switchOn`, `switchKnob`, `switchKnobActive` | `<GlassSwitch>`: track off / on, knob at rest / as glass |
| `sliderTrack`, `sliderFill`, `sliderKnob`, `sliderKnobActive` | `<GlassSlider>` parts |
| `chip`, `alert`, `alertRinging`, `alertMissed` | Small capsules |
| `topbar`, `headerButton` | A floating header capsule and the buttons in it |
| `dock`, `menu`, `chatPanel`, `dialPanel`, `notifPanel`, `scheduleTip` | Floating panels (the `float` layer) |
| `navActive`, `sidebar` | A sliding "lens" for the current menu item; a sidebar (off by default) |
| `modal`, `confirmPanel` | Dialogs (the `modal` layer, see "Layers") |
| `liquid`, `chatMorph`, `dialMorph`, `notifMorph` | Liquid morph groups |
| `easterOrb` | A big, thick lens (the `top` layer) |

Make your own in the config: `groups: { myCard: { tint: '#fde68a', blur: 16 } }`.

---

## Configuration

Pass a config to `<GlassProvider config={…}>`, to `configureGlass(config)`, or to `window.GlassparencyConfig`.
It is **deep‑merged over the built‑in config**, so list only what you change.

```js
{
  global:   { … },                 // switches for the whole system (below)
  defaults: { … },                 // used by every group
  groups:   {
    button: { tintOpacity: 0.74, hover: { tintOpacity: 0.95 } },
    myCard: { tint: { from: '#c7d2fe', to: '#a5f3fc', angle: 135 }, blur: 14 },
  },
  themes:   { dark: { defaults: { … }, groups: { button: { tint: '#1e293b' } } } },
}
```

Bad values never break the page: they are clamped or replaced with the default, with one console warning each.

### Properties (per group, per element, or in `hover` / `pressed` / `disabled` blocks)

| Property | Values | What it does |
|---|---|---|
| `enabled` | true/false | Glass on/off for the group. Off = the element's normal CSS, plus the colours / border / shadow / shape the group sets *itself*, as plain CSS |
| `sampler` | `auto`, `webgl`, `live` | How floating glass sees the page. `live` = the real page in real time (Chromium). `webgl` = page pictures. `auto` = live where possible |
| `shape` | `rectangle`, `roundedRectangle`, `circle`, `capsule` | Outline of the slab |
| `radius` | px or `"auto"` | Corner radius (`auto` = the element's CSS `border-radius`, or 16 px) |
| `scale` | `{ x, y }` 0.5–1.5 | Glass size relative to the element |
| `bleed` | `{ top, right, bottom, left }` px | Hide the rim on those sides (full‑width bars) |
| `padding` | `{ top, right, bottom, left }` px | Moves the element in by this much (e.g. a header floating as a capsule) |
| `thickness` | 0–120 | Refraction strength |
| `bevel`, `bevelSegments` | 0–120 px, 1–16 | Width and smoothness of the rounded rim (only the rim bends light) |
| `profile` | `squircle`, `classic` | Rim curve: Apple‑style lens, or a quarter circle |
| `ior` | 1–2.5 | Index of refraction |
| `chromaticAberration` | 0–1 | Rainbow fringing at the rim |
| `blur` | px | Frost |
| `roughness`, `anisotropy` | 0–1 | Grain, directional smear (WebGL) |
| `distortion`, `distortionScale`, `temporalDistortion` | 0–2, 0–1 | Wavy / animated warp (WebGL; animated = GPU every frame) |
| `samples` | 1–16 | Refraction quality (WebGL) |
| `reflection` | 0–3 | Studio reflections on steep rims (WebGL) |
| `saturation`, `brightness` | 0–3, 0.5–1.5 | Colour of what's seen through the glass |
| `rimLight`, `rimWidth`, `lightAngle`, `innerGlow` | 0–1, px, deg, 0–1 | Specular rim and inner glow (CSS angles: −45 = top‑left) |
| `pressScale`, `pressGlow` | 0.8–1.2, 0–1 | Grow and light up when pressed |
| `morph`, `morphRadius` | name, px | Glass with the same morph name (same layer) melts together within that distance |
| `tint`, `tintOpacity` | colour or `{ from, via?, to, angle }`, 0–1 | Glass colour / gradient and how strong it is |
| `textColor`, `font`, `fontWeight`, `iconColor`, `iconSize` | CSS values | Text and `<svg>` icon style while glass is on |
| `borderWidth`, `borderColor`, `borderOpacity` | px, colour, 0–1 | Hairline border drawn by the glass (follows its shape) |
| `shadowColor`, `shadowOpacity`, `shadowBlur`, `shadowX`, `shadowY`, `shadowSpread` | colour, 0–1, px | Drop shadow drawn by the glass |
| `keepBorder`, `keepShadow` | true/false | Also keep the element's own CSS border / box‑shadow |
| `layer`, `tier` | `auto`/`base`/`float`/`modal`/`top`, `auto`/0–5 | Which canvas draws it, and the order inside it |

**Colours** can be any CSS colour (`#hex`, `rgb()`, `hsl()`, `oklch()`, names) or `var(--token)`, read from the
element (also `var(--token, fallback)`). A colour's own alpha is ignored: use the matching `…Opacity` property.

### `global`

| Key | Default | Meaning |
|---|---|---|
| `enabled` | `true` | Master switch (false = your CSS everywhere) |
| `root` | `"body"` | CSS selector of your app's root. Its changes trigger redraws, and WebGL floating glass photographs it |
| `background` | `"auto"` | What base glass refracts (see "Page background") |
| `mobileQuery` | `"(max-width: 860px)"` | Layout that never starts WebGL (phones get your CSS). `null` = always try |
| `zIndex` | `{ base: -1, float: 49 }` | Stacking of the page‑wide canvases (see "Layers") |
| `theme` | `"auto"` | `"light"` / `"dark"` forces a theme |
| `anchor` | `"viewport"` | `"page"` = the canvases scroll with the page (see "Phones and tablets") |
| `maxDpr`, `bufferScale` | 1.5, 1 | Render resolution caps |
| `snapshot` | `{ enabled, debounceMs, minIntervalMs, margin, scale }` | Page pictures for WebGL floating glass |
| `debugOutlines` | `false` | Pink outline round every slab |

---

## How it works (and what your page needs)

### Layers
Browsers allow only ~16 WebGL contexts, so glass is drawn by one transparent, click‑through canvas **per
layer**, not per element:

| Layer | z-index | What it sees |
|---|---|---|
| `base` | `global.zIndex.base` (−1) | Behind all page content. It refracts the page background (cards, buttons, sidebars). |
| `float` | `global.zIndex.float` (49) | Over the content. Headers, docks, menus. In Chromium it refracts the live page; elsewhere a picture of it. |
| `modal` | inside your dialog | Put `<GlassLayerHost />` inside your dialog's backdrop element. The backdrop's colour is used as the dimmer. |
| `top` | inside your container | Put `<GlassLayerHost layer="top" />` in a positioned container. |

- A layer is picked automatically from the nearest glass parent. A group can force one with `layer`.
- Glass on glass works: a button refracts the card it sits on.
- Elements of a layer with no host (e.g. `modal` without `<GlassLayerHost>`) simply keep their CSS look.

**Checklist for your page:**
1. **Base glass needs a see‑through page.** The base canvas sits just above `<html>`/`<body>`. If a full‑page
   wrapper paints an opaque background over it, base glass is hidden. Give that wrapper
   `background: transparent`, or raise `global.zIndex.base`.
2. **Floating glass HTML must stack above the float canvas.** For example, a header with glass needs a
   `z-index` above 49 (or lower `global.zIndex.float`). Otherwise the canvas draws over its text in Safari
   and Firefox.
3. **Don't put `transform`, `filter` or `backdrop-filter` on an ancestor of a layer host.** It creates a
   new containing block.
4. **The glass replaces the element's background.** `:hover` background changes in your CSS won't show
   while glass is on. Use the group's `hover` block instead.
5. **Live glass draws on the element's `::before`.** Live elements shouldn't use `::before` themselves.
6. **Live glass scrolls with the element.** If a live element scrolls, put its content in an inner scroll
   box. Otherwise the glass scrolls away with the content.

### Page background
Base glass refracts a shader copy of the page background:
- **`"auto"` (default):** your `<body>` (or `<html>`) background **colour**, read live. Your real background
  stays visible. Gradients and images are refracted as their base colour.
- **An exact copy:** to match a gradient background, describe it per theme. It is then also drawn on screen
  under the glass.

```js
global: { background: {
  light: { base: { top: '#f5f7fd', bottom: '#eef1fa' },
           glows: [{ rx: 900, ry: 600, at: [0, 0], rgb: [99, 102, 241], alpha: 0.16, stop: 0.6 }] },
  dark:  { base: { top: '#0e1224', bottom: '#0b0e1a' } },
} }
```

### Live glass (Chromium) vs WebGL glass
- **Chromium (Chrome, Edge, Arc, Brave, Opera, Samsung Internet):** `backdrop-filter: url(#svg-filter)`
  bends the real page every frame — text, video, animations. It uses the same config: `thickness × (ior−1)`
  sets the bend, plus `bevel`, `chromaticAberration`, `blur`, `tint`, rim light and shape.
- **WebGL‑only properties:** `scale`, `anisotropy`, `roughness`, `distortion`, `samples` and `reflection`.
- **Safari and Firefox:** floating glass is WebGL. It refracts a picture of the page taken with
  [snapDOM](https://github.com/zumerlab/snapdom), retaken after changes, and up to ~0.5 s old.
  - Cross‑origin images without CORS headers are left out of the picture.
  - Mark heavy or private areas with `data-glass-ignore` to leave them out too.

### Liquid morph
Elements with the same `morph` name are drawn by one shader as a single smooth surface. Closer than
`morphRadius`, they melt into one; moving apart, they split into drops.

**Where morph glass must sit.** Melting needs the WebGL shader, so:
- **Not inside live glass.** In Chromium, glass inside a live glass element (e.g. inside a glass card)
  is drawn as a tint only, and the shapes won't melt. Put the morph elements in a parent without glass.
- **Use the `float` layer over a gradient or image page background.** With `background: "auto"`, WebGL
  glass on the `base` layer isn't drawn there, so the shapes keep their CSS look. Give them
  `layer: 'float'` (per group, or per element: `<Glass group="liquid" glass={{ layer: 'float' }} />`).
  On a plain-colour background, `base` works too.

To animate a morph frame by frame:
1. Move the elements yourself each `requestAnimationFrame`.
2. Change their look with `setGlassProps(el, { tintOpacity, blur, radius })` (no re‑render).
3. Call `reserveSnapshotArea(key, rect)` for the area the shapes will cover, and pass `null` when done.

### Dark mode
The top‑level settings are the light look. `themes.dark` lists only what changes. The theme is read live
from (first match wins):
1. `global.theme`;
2. `data-theme` / `data-bs-theme` on `<html>`/`<body>`;
3. a `dark` / `light` class on `<html>`/`<body>`;
4. the page's CSS `color-scheme`.

A site that never mentions dark mode stays light.

### Phones and tablets
- **Default:** below `mobileQuery` (860 px wide) the glass doesn't start, and your CSS shows instead.
- **Why:** mobile browsers scroll the page on their own thread and tell the page afterwards. A canvas fixed
  to the window is always redrawn a frame or more late, so its glass trails the content while you scroll.
- **To use the glass on phones,** set `global.anchor: "page"` together with `mobileQuery: null`. The canvases
  then sit *in the page*, round the visible part, so the browser scrolls the drawn glass together with the
  content and it stays glued, even mid-fling.
- **Pinned elements:** glass on fixed / sticky elements (a fixed nav) can't scroll with the page, so in this
  mode it keeps its CSS look (or uses live glass where that runs).

```js
const touch = matchMedia('(pointer: coarse)').matches;
<GlassProvider config={{ global: touch ? { anchor: 'page', mobileQuery: null } : {} }}>
```

### Fallbacks (automatic, no layout change)
Your own CSS is used when:
- `global.enabled` is false;
- the layout matches `global.mobileQuery`;
- the OS **Reduce transparency** setting is on;
- the browser has no **hardware** WebGL 2 (software renderers, blocklisted GPUs);
- the graphics card resets (context lost);
- the browser has no window (server).

`getGlassStatus()` / `Glassparency.status()` says which applies.

### Performance
- **Idle cost:** nothing is drawn while nothing changes (scroll, resize, DOM changes, hover and CSS
  animations trigger frames).
- **Frame cost:** a frame is 0.5–2 ms.
- **Lazy loading:** three.js and snapDOM load lazily after first paint, and only where glass can run.

### Content-Security-Policy
- The provider adds one `<style>`. Pass `nonce`, or set `injectStyles={false}` and import
  `glassparency/glass.css` yourself.
- Live glass uses `data:` images inside SVG filters, so `img-src` must allow `data:`.

---

## API

| Export | |
|---|---|
| `<GlassProvider config renderIcon injectStyles nonce>` | Starts the glass (once per page) |
| `<Glass as group glass icon iconSize …>` | An element with glass. `icon` = an element, or a name drawn by `renderIcon(name, size)` |
| `useGlass(ref, group, props?)` | The hook |
| `<GlassSwitch>`, `<GlassSlider>` | Liquid Glass switch and slider (see "Switches and sliders") |
| `createSwitch(el, opts)`, `createSlider(el, opts)` | The same without React |
| `attachGlass(el, group, props?) → { setProps, destroy }` | The same without React |
| `setGlassProps(el, props)` | Change an element's look without a render (animations) |
| `configureGlass(config)` / `getGlassConfig()` | Merge a config over the built‑in one / read the result |
| `requestGlassRender()` | Redraw now (after moving elements outside `global.root` yourself) |
| `reserveSnapshotArea(key, rect)` | See "Liquid morph" |
| `<GlassLayerHost layer>` | A canvas for the `modal` / `top` layer |
| `getGlassStatus()`, `subscribeGlassStatus(fn)`, `glassStats` | State and frame / picture timings |
| `GLASS_SCHEMA`, `resolveGlass`, `setGlassOverride`, `setGlassStateOverride`, `setGlassForcedState`, … | Build a live tuning panel |

## Requirements
- **React apps:** React 19 (19.0–19.3, the range react‑three‑fiber 9 supports), three ≥ 0.159,
  @react-three/fiber 9 and @react-three/drei ≥ 10.7.
- **Script build:** no requirements.
- **Browsers:** WebGL glass needs WebGL 2 (every current desktop browser). Everything else falls back to
  your CSS.

## License
MIT © RicoSuaveDev
