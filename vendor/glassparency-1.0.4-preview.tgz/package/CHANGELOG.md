# Changelog

## 1.0.3 — 2026-10-16

- Showcase now live and ready.
- Redesigned switches and sliders.

## 1.0.2 — 2026-10-16

- Added showcase images.

## 1.0.1 — 2026-10-16

- Fixed License Issue

## 1.0.0 — 2026-10-16

- Glassparency brings the new age glass aesthetic to your website with minimum effort.
- Using WebGL and DOM snapshots for real-time refraction, glassparency is able to mimic the look of glass without the need for complicated shaders or CSS workarounds.
- Don't settle for a replica, get the real deal.

